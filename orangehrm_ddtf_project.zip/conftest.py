# Common pytest fixtures can be added here
